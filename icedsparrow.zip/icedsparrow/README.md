# Moduł IcedSparrow

## Opis
Moduł IcedSparrow to moduł PrestaShop stworzony przeze mnie  Dawida Wróbl jako  zadanie rekrutacyjnego. 

## Instalacja
1. Pobierz katalog `icedsparrow`. Z GitHuba
2. Przejdz do Menedżera modułów i kliknij Załąduj Moduł i wyberz moduł `icedsparrow`.
3. Po załadowaniu kliknij na link "Konfiguruj", aby skonfigurować ustawienia modułu.

## Konfiguracja
- **Treść na Stronie Głównej**: Skonfiguruj treść do wyświetlenia na stronie głównej.Wedle upodoban  

## Użycie
1. Przejdź do strony konfiguracji modułu, klikając na link "Konfiguruj" w sekcji Moduły i Menedżer modułów.
2. Skonfiguruj żądaną treść do wyświetlenia na stronie głównej.
3. Zapisz ustawienia.
4. Opcjonalnie skonfiguruj, czy wyświetlać treść tylko dla zalogowanych lub niezalogowanych użytkowników.
5. Sprawdź stronę główną swojego sklepu PrestaShop, aby zobaczyć zaktualizowaną treść.

## Dezinstalacja
1. Przejdź do sekcji Moduły i wejdz do Menedżer modułów w panelu administracyjnym PrestaShop.
2. Wyszukaj "IcedSparrow" na liście modułów.
3. Kliknij przycisk "Odinstaluj", aby odinstalować moduł.
4. Potwierdź dezinstalację.
5. Moduł zostanie odinstalowany z twojej instalacji PrestaShop.


## Wersja
- **Wersja**: 1.0.0

## Autor
- **Autor**: Dawid Wróbel

